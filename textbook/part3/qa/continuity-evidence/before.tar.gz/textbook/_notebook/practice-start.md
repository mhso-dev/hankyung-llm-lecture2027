# 실습 시작하기

이 자료는 처음 개발하는 수강생이 코드를 한 단계씩 실행하며 배우는 실습용 노트북입니다. Python 3.12를 사용하는 Jupyter Notebook·JupyterLab 또는 VS Code의 Jupyter 노트북 화면에서 엽니다.

## 1. 실습 파일 준비

압축을 풀면 `llm-practice` 폴더가 생깁니다. 이 폴더 안의 `labs` 폴더에는 노트북과 실습 문서가 함께 있습니다. 파일을 낱개로 옮기면 데이터 경로를 찾지 못할 수 있으므로 폴더 구조를 유지합니다.

모델을 호출하는 API 실습에서는 `llm-practice` 폴더의 `env.example`을 복사해 `.env`라는 이름으로 저장합니다. `OPENAI_API_KEY=` 오른쪽에 본인의 키를 넣습니다. 키를 채팅·노트북 코드·출력에 붙여 넣지 않습니다. API를 호출할 때는 계정에 사용 요금이 발생할 수 있습니다.

## 처음 개발하는 경우: Ch 1부터 준비하기

Ch 1은 API 키 없이 숫자·파일·개발 도구를 다룹니다. uv와 VS Code를 설치한 뒤 `labs/part1/ch01-development-environment` 폴더를 VS Code에서 엽니다. 해당 폴더의 `README.md`에 실행 순서가 있습니다. 폴더 안에서 `uv sync --locked`로 환경을 준비하고 Python 인터프리터와 노트북 커널을 모두 이 프로젝트의 `.venv`로 선택합니다. Docker 서버가 준비되지 않았더라도 숫자·경로·가상환경·스크립트 실습은 진행할 수 있습니다. Docker 실습 전에 Docker가 설치되어 있고 실행 중인지 확인합니다.

## Ch 2 파이썬 학습 경로

`labs/part1/ch02-python/README.md`에서 환경 준비 순서를 확인합니다. A트랙은 01~08절의 기초 문법·테스트를 학습하고 12절로 이어갑니다. B트랙은 기초를 점검한 뒤 09~11절의 데코레이터·데이터 검증·패키징과 테스트 격리를 학습합니다. 12절의 비동기 프로그래밍은 두 트랙 모두 필수입니다. 실습에는 API 키가 필요하지 않습니다.

## 2. 노트북 열기

Part 1에서는 Ch 1·2를 마친 뒤 Git 협업(Ch 3), 데이터 조회(Ch 4), LLM 동작 원리(Ch 5)를 학습합니다. Ch 3은 임시 저장소와 가상 자료로 실습하며 실제 프로젝트 이력을 변경하지 않습니다. Ch 4는 제공 데이터와 로컬 HTTP 서버를 사용합니다. Ch 5는 로컬 모델 파일을 처음 실행할 때 내려받으므로 인터넷 연결과 여유 저장 공간이 필요합니다. 자세한 준비 사항은 각 장의 README에서 확인합니다. Part 1에는 유료 모델 API 키가 필요하지 않습니다. 첫 외부 모델 API 호출은 Ch 6에서 시작합니다.

Part 2는 `labs/part2/ch06-langchain-start` → `ch07-prompt-engineering` → `ch08-context-engineering` 순서로 학습합니다. Ch 6의 세 제공자 비교에서 Anthropic과 Google도 실행하려면 `.env`에 `ANTHROPIC_API_KEY`와 `GOOGLE_API_KEY`를 추가합니다. 키가 없는 제공자는 미실행으로 표시되며, 비용이나 지연이 0이라는 뜻은 아닙니다. 각 챕터의 `README.md`에서 준비와 실행 범위를 확인합니다.

처음 실습한다면 VS Code를 기준으로 다음 순서로 준비합니다. Python 3.12를 먼저 설치해야 하며 VS Code 설치만으로 Python이 함께 설치되지는 않습니다.

1. [VS Code 시작 안내](https://code.visualstudio.com/docs/getstarted/overview)에 따라 VS Code를 설치하고 **File > Open Folder**에서 압축을 푼 `llm-practice` 폴더를 엽니다.
2. 확장 화면에서 Microsoft의 **Python** 확장과 **Jupyter** 확장을 설치합니다. [공식 노트북 안내](https://code.visualstudio.com/docs/datascience/jupyter-notebooks)에서 확장 설치와 파일 열기를 확인할 수 있습니다.
3. 왼쪽 파일 목록에서 원하는 `.ipynb`를 엽니다. 첫 RAG 실습은 `labs/part3/ch09-rag-first-run/notebooks/01-RAG-지도.ipynb`입니다.
4. 노트북 오른쪽 위 **Select Kernel → Python Environments**에서 Python 3.12 환경을 고릅니다. 커널은 코드를 실행하고 변수를 기억하는 프로그램입니다. 환경을 만들 때는 [Python 환경 준비 안내](https://code.visualstudio.com/docs/python/environments)의 **Python: Create Environment**에서 설치된 Python 3.12를 선택합니다.
5. 선택한 커널이 Python 3.12인지 확인한 뒤 첫 셀부터 실행합니다. [커널 선택 안내](https://code.visualstudio.com/docs/datascience/jupyter-kernel-management)에서 다른 환경으로 바꾸는 방법을 확인할 수 있습니다.

이미 Python 3.12 커널을 갖춘 Jupyter Notebook·JupyterLab이 있다면 그 환경에서 파일을 열어도 됩니다. 이 압축 파일에는 Python이나 편집 프로그램이 포함되어 있지 않습니다. 패키지 설치와 API 호출에는 인터넷 연결이 필요합니다.

## 3. 첫 셀부터 실행

노트북에는 설명을 읽는 셀과 코드를 실행하는 셀이 있습니다. 코드 셀을 선택하고 `Shift+Enter`를 누르면 실행 후 다음 셀로 이동합니다. 설치 셀이 있는 절은 해당 셀이 필요한 라이브러리를 준비할 때까지 기다립니다. 셀의 실행 표시가 사라질 때까지 기다린 뒤 오류 메시지가 없는지 확인합니다. Jupyter에서는 `[*]`가 숫자로 바뀌면 실행이 끝난 것입니다.

설명 → 기본 실행 → 결과 관찰 → 값 변경 → 결과 비교 순서로 진행합니다. 앞 셀이 만든 변수를 다음 셀에서 사용하므로 처음 실행할 때는 셀을 건너뛰지 않습니다. 출력 전체를 외우기보다 안내에서 지정한 본문, 문서 수, 숫자 목록의 길이, 출처 등을 확인합니다. 모델이 생성한 문장은 교재와 다를 수 있습니다.

## 4. 값을 바꾸어 보기

먼저 제공된 코드로 정상 결과를 확인합니다. 그다음 함수에 전달하는 값이나 입력 문장 중 안내된 하나만 바꾸고 해당 셀을 실행합니다. 변경 전후 결과를 비교한 뒤 기본값으로 되돌리면 이후 실습을 같은 조건에서 이어갈 수 있습니다.

Before/After가 있는 절에서는 Before로 실제 실패를 확인하고 After로 같은 원인을 수정합니다. 같은 노트북에서 차례대로 실행합니다. Ch 8의 Context rot 측정처럼 현상을 관찰하는 절은 Before/After 대신 실험 결과를 해석합니다. 일부 예제는 오류가 나면 이유를 출력하고 다음 셀로 진행하도록 작성되어 있습니다. 이런 경우와 오류 때문에 실행이 멈춘 경우를 구분해 확인합니다.

## 5. 실행이 막혔을 때

- `NameError`: 앞의 준비 셀이 실행되지 않았거나 커널이 바뀌었는지 확인하고 첫 셀부터 다시 실행합니다.
- `ModuleNotFoundError`: 해당 절의 설치 셀을 실행했는지 확인합니다. 설치 뒤에도 같은 오류가 나면 커널을 다시 시작하고 첫 셀부터 실행합니다.
- `.env` 또는 키 관련 오류: 압축을 풀어 생긴 `llm-practice` 폴더의 `.env` 파일명과 키 이름을 확인합니다. 키 값을 출력해서 확인하지 않습니다.
- `FileNotFoundError`: 노트북과 실습 문서를 함께 압축 해제했는지, `labs` 폴더 구조를 유지했는지 확인합니다.
- 예상과 다른 변수나 결과가 남아 있다면 커널을 다시 시작하고 첫 셀부터 실행합니다. 재시작하면 이전 변수는 사라집니다.

실습 문서에는 수업을 위해 만든 가상 자료가 포함되어 있습니다. 이 자료에서 검색이 잘되더라도 실제 업무 문서에서도 같은 결과가 나오는지는 따로 확인해야 합니다.
