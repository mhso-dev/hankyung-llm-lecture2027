# Ch 12 검색 품질 실습

Python 3.12와 uv를 사용합니다. 노트북은 각각 빈 커널에서 독립 실행되며, 01~02절, 05~06절, 11~12절은 프로젝트 루트 `.env`의 `OPENAI_API_KEY`가 필요합니다. 키 값은 노트북 출력에 표시하지 않습니다.

pgvector 실습은 `pgvector/pgvector:0.8.2-pg17` 이미지로 만든 `hankyung-part3-pgvector` 컨테이너를 사용합니다. 호스트의 `127.0.0.1:55432`에만 포트를 공개하고, 전용 `rag_lab` 데이터베이스의 `ch12_core_*` 테이블만 변경합니다. 연결 문자열은 `postgresql://student:local-practice-only@127.0.0.1:55432/rag_lab`입니다. 이 암호는 로컬 수업 전용이며 다른 환경에서 사용하지 않습니다.

```bash
docker run --name hankyung-part3-pgvector \
  -e POSTGRES_USER=student \
  -e POSTGRES_PASSWORD=local-practice-only \
  -e POSTGRES_DB=rag_lab \
  -p 127.0.0.1:55432:5432 \
  -d pgvector/pgvector:0.8.2-pg17
```

실습 후 `docker stop hankyung-part3-pgvector`로 중지합니다. 같은 데이터를 다시 사용할 때는 `docker start hankyung-part3-pgvector`로 시작합니다.

07~08절과 12절은 로컬 CrossEncoder 모델을 사용합니다. 첫 실행에서는 모델 파일을 내려받으므로 인터넷 연결과 저장 공간이 필요합니다. 다운로드 시간과 추론 시간은 구분해서 읽습니다. 11절의 질문 재작성과 12절의 통합 예제는 실제 모델 API를 호출하므로 사용량에 따른 비용이 발생합니다.

전반은 교육용 문서 12개와 질문 8개를 사용합니다. 후반의 `data/advanced-documents.json`과 `data/advanced-queries.json`은 제공 PDF 6건에 대응하는 본문과 평가 질문 30개입니다. 압축을 푼 전체 폴더를 유지해야 12절이 `labs/data/rag-corpus/pdf`의 PDF를 직접 읽을 수 있습니다.

`runs/advanced-experiment-log.jsonl`에는 TF-IDF와 MMR의 개발 설정 36건, `runs/advanced-test-result.json`에는 선택한 설정의 시험 평가 1건을 기록합니다. `runs/advanced-integrated-result.json`은 dense·Kiwi BM25·RRF·CrossEncoder·부모 본문 선택·답변 생성을 연결한 별도 실행 1건입니다. 개발 질문 15개와 시험 질문 15개를 구분하며, 작은 합성 자료의 결과를 실제 업무 전체의 품질로 해석하지 않습니다.
