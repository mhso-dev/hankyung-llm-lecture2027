from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from collections import Counter
from datetime import date
from pathlib import Path

from pypdf import PdfReader


def find_repo_root(start: Path) -> Path:
    for folder in (start, *start.parents):
        if (folder / "labs" / "data" / "rag-corpus" / "manifest.json").exists():
            return folder
    raise FileNotFoundError("labs/data/rag-corpus를 찾지 못했습니다.")


def tokens(text: str) -> list[str]:
    normalized = re.sub(r"\s+", " ", text.lower())
    words = re.findall(r"[가-힣a-z0-9]+", normalized)
    compact = re.sub(r"[^가-힣a-z0-9]", "", normalized)
    return words + [compact[i : i + 2] for i in range(max(0, len(compact) - 1))]


def load_pages(corpus: Path) -> list[dict]:
    manifest = json.loads((corpus / "manifest.json").read_text(encoding="utf-8"))
    pages = []
    for item in manifest:
        if item["tier"] == "scanned":
            continue
        pdf_path = corpus / item["file"]
        for page_no, page in enumerate(PdfReader(pdf_path).pages, start=1):
            text = page.extract_text() or ""
            if text.strip():
                pages.append({"doc_id": item["doc_id"], "page": page_no, "text": text})
    return pages


def corpus_fingerprint(corpus: Path) -> str:
    manifest_bytes = (corpus / "manifest.json").read_bytes()
    manifest = json.loads(manifest_bytes)
    digest = hashlib.sha256(manifest_bytes)
    for item in sorted(manifest, key=lambda row: row["file"]):
        if item["tier"] != "scanned":
            digest.update((corpus / item["file"]).read_bytes())
    return digest.hexdigest()


def search(question: str, pages: list[dict], limit: int = 50) -> list[dict]:
    query_counts = Counter(tokens(question))
    scored = []
    for page in pages:
        page_counts = Counter(tokens(page["text"]))
        overlap = sum(min(count, page_counts[token]) for token, count in query_counts.items())
        score = overlap / math.sqrt(max(1, sum(page_counts.values())))
        scored.append({"doc_id": page["doc_id"], "page": page["page"], "score": score})
    ranked_pages = sorted(scored, key=lambda row: (-row["score"], row["doc_id"], row["page"]))
    unique_docs = []
    seen = set()
    for row in ranked_pages:
        if row["doc_id"] not in seen:
            unique_docs.append(row)
            seen.add(row["doc_id"])
    return unique_docs[:limit]


def recall_at(results: list[dict], gold: set[str], k: int) -> float:
    results = dedupe_docs(results)[:k]
    found = {row["doc_id"] for row in results}
    return len(found & gold) / len(gold) if gold else 0.0


def precision_at(results: list[dict], gold: set[str], k: int) -> float:
    top = dedupe_docs(results)[:k]
    return sum(row["doc_id"] in gold for row in top) / k if k else 0.0


def ndcg_at(results: list[dict], gold: set[str], k: int) -> float:
    gains = [1.0 if row["doc_id"] in gold else 0.0 for row in dedupe_docs(results)[:k]]
    dcg = sum(gain / math.log2(rank + 2) for rank, gain in enumerate(gains))
    ideal_count = min(k, len(gold))
    idcg = sum(1.0 / math.log2(rank + 2) for rank in range(ideal_count))
    return dcg / idcg if idcg else 0.0


def dedupe_docs(results: list[dict]) -> list[dict]:
    unique = []
    seen = set()
    for row in results:
        if row["doc_id"] not in seen:
            unique.append(row)
            seen.add(row["doc_id"])
    return unique


def evaluate(dataset: list[dict], pages: list[dict], top_k: int) -> dict:
    eligible = [item for item in dataset if item.get("answerable") and item.get("gold_doc_ids")]
    rows = []
    for item in eligible:
        results = search(item["question"], pages, limit=50)
        gold = set(item["gold_doc_ids"])
        rows.append({
            "qid": item["qid"], "tier": item["tier"], "split": item["split"], "type": item["type"],
            "gold_doc_ids": sorted(gold), "returned_count": len(results),
            "recall_at_5": recall_at(results, gold, 5), "recall_at_50": recall_at(results, gold, 50),
            "precision_at_5": precision_at(results, gold, 5),
            "ndcg_at_5": ndcg_at(results, gold, 5),
            "top_doc_ids": [row["doc_id"] for row in results[:top_k]],
        })
    metric_keys = ("recall_at_5", "recall_at_50", "precision_at_5", "ndcg_at_5")
    metrics = {key: (sum(row[key] for row in rows) / len(rows) if rows else None) for key in metric_keys}
    tiers = sorted({row["tier"] for row in rows})
    slices = {tier: {key: sum(row[key] for row in rows if row["tier"] == tier) / sum(row["tier"] == tier for row in rows) for key in metrics} for tier in tiers}
    return {"run_id": "lexical-doc-v1", "run_date": date.today().isoformat(), "settings": {"retriever": "word+bigrams", "candidate_k": 50, "report_k": top_k}, "metrics_policy": "unique-doc-macro-v1", "metrics": metrics, "slices": slices, "query_count": len(rows), "excluded_query_count": len(dataset) - len(eligible), "results": rows}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--top-k", type=int, default=5)
    parser.add_argument("--output", type=Path, default=Path("runs/baseline.json"))
    args = parser.parse_args()
    root = find_repo_root(Path.cwd())
    dataset_path = root / "labs" / "part3" / "ch11-evaluation" / "data" / "evaluation-queries.jsonl"
    dataset = [json.loads(line) for line in dataset_path.read_text(encoding="utf-8").splitlines() if line]
    corpus = root / "labs" / "data" / "rag-corpus"
    report = evaluate(dataset, load_pages(corpus), args.top_k)
    report["corpus_fingerprint"] = corpus_fingerprint(corpus)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"metrics": report["metrics"], "query_count": report["query_count"], "output": str(args.output)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
