import importlib.util
from pathlib import Path


spec = importlib.util.spec_from_file_location("ch11_evaluate", Path(__file__).parents[1] / "evaluate.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
evaluate = module.evaluate
ndcg_at = module.ndcg_at
precision_at = module.precision_at
recall_at = module.recall_at


def ranked(count=51):
    return [{"doc_id": f"D{i:02d}", "page": 1, "score": 1 / i} for i in range(1, count + 1)]


def test_cutoff_boundaries():
    results = ranked()
    assert recall_at(results, {"D06"}, 50) == 1.0
    assert precision_at(results, {"D06"}, 5) == 0.0
    assert ndcg_at(results, {"D06"}, 5) == 0.0
    assert recall_at(results, {"D51"}, 50) == 0.0


def test_duplicate_doc_ids_are_counted_once():
    results = [
        {"doc_id": "G", "page": 1},
        {"doc_id": "G", "page": 2},
        {"doc_id": "X", "page": 1},
    ]
    assert precision_at(results, {"G"}, 2) == 0.5
    assert ndcg_at(results, {"G"}, 2) == 1.0


def test_empty_results_and_empty_gold_policy():
    assert recall_at([], {"G"}, 50) == 0.0
    assert precision_at([], {"G"}, 5) == 0.0
    assert ndcg_at([], {"G"}, 5) == 0.0
    dataset = [{"qid": "Q0", "tier": "easy", "split": "dev", "type": "single", "question": "없음", "gold_doc_ids": [], "answerable": False}]
    report = evaluate(dataset, [], 5)
    assert report["query_count"] == 0
    assert report["excluded_query_count"] == 1
