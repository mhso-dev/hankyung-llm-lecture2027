# Chapter 11 평가 기초 실습

노트북은 각각 새 Python 3.12 커널에서 독립 실행됩니다. 제공된 30개 학습용 질문과 공개 PDF를 사용하며, 정답 문서 ID는 검색 지표 계산을 위해 포함합니다. 답변 문자열과 비공개 정답 자료는 포함하지 않습니다.

```bash
uv run python evaluate.py --top-k 5 --output runs/baseline.json
```

자동 평가 결과의 기본 스키마는 `run_id`, `run_date`, `settings`, `metrics_policy`, `corpus_fingerprint`, `metrics`, `slices`, `query_count`, `excluded_query_count`, `results`입니다. `metrics`에는 `recall_at_5`, `recall_at_50`, `precision_at_5`, `ndcg_at_5`가 들어갑니다. 질문별 결과에는 `gold_doc_ids`, `returned_count`, 상위 문서 ID를 함께 남깁니다. Chapter 12에서도 설정·지표·입력 식별자를 함께 기록하며, 절별 로그 형식은 해당 실습에서 확인합니다.
