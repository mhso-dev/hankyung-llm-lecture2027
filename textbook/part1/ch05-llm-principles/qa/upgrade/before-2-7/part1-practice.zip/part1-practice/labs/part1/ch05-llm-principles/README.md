# Ch 5 LLM 동작 원리 실습

Python 3.12와 `uv`를 사용합니다. 노트북은 서로 독립적이며 첫 셀부터 순서대로 실행합니다. 압축을 풀고 `labs/part1/ch05-llm-principles` 폴더에서 터미널을 연 뒤 다음 명령을 실행합니다.

```bash
uv sync --locked
uv run --with jupyterlab==4.4.9 jupyter lab
```

JupyterLab이 열리면 현재 프로젝트의 Python 커널을 선택하고 각 노트북을 첫 셀부터 `Shift+Enter`로 실행합니다. VS Code에서도 같은 커널을 선택해 실행할 수 있습니다.

01 노트북은 Part 1 배포 묶음의 `labs/part1/ch04-data-tools/data/article-text.json`을 읽습니다. Ch 4와 Ch 5 폴더의 상대 위치를 바꾸지 않고 배포 묶음 구조를 유지합니다.

첫 실행은 Hugging Face에서 토큰화기·임베딩·생성 모델 파일을 다운로드하므로 네트워크와 저장 공간이 필요합니다. 검증 컴퓨터에서 Qwen 캐시는 953 MiB, multilingual MiniLM 캐시는 458 MiB, 가상환경은 676 MiB를 사용했습니다. 캐시 파일 공유와 파일 시스템에 따라 실제 디스크 사용량은 달라질 수 있습니다. 오프라인 실행은 필요한 파일이 모두 캐시에 있고 각 로더에 오프라인 옵션을 지정한 경우에만 가능합니다. 메모리가 부족하면 다른 노트북을 열기 전에 기존 커널을 종료합니다. 실제 메모리와 속도는 장비에 따라 달라집니다.

실행 출력에 `TqdmWarning: IProgress not found`가 나타나도 뒤의 계산과 검증 결과가 계속 출력되면 실행 실패가 아닙니다. 진행률 표시 위젯을 사용할 수 없다는 경고입니다.
