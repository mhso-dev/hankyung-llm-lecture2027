# Ch 6 LangChain 시작 실습

Python 3.12와 `uv`를 사용합니다. 프로젝트 루트의 `.env`에서 API 키를 읽으며 키 값은 출력하지 않습니다. 여섯 노트북은 각각 새 커널에서 독립 실행할 수 있습니다. Anthropic과 Google 키가 없으면 관련 비교 행은 `skipped`로 기록됩니다.
