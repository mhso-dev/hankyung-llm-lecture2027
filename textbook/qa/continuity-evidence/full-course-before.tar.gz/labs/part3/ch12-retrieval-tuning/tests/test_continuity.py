import ast
import json
import re
from pathlib import Path

import numpy as np
import pytest
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


ROOT = next(
    path
    for path in (Path(__file__).resolve(), *Path(__file__).resolve().parents)
    if (path / "labs/part3/ch12-retrieval-tuning").exists()
)
CH12 = ROOT / "labs/part3/ch12-retrieval-tuning"


def load_notebook_function(notebook_name, function_name, namespace=None):
    notebook = json.loads((CH12 / "notebooks" / notebook_name).read_text())
    for cell in notebook["cells"]:
        if cell["cell_type"] != "code":
            continue
        tree = ast.parse("".join(cell["source"]))
        for node in tree.body:
            if isinstance(node, ast.FunctionDef) and node.name == function_name:
                module = ast.Module(body=[node], type_ignores=[])
                scope = {"np": np, "cosine_similarity": cosine_similarity, **(namespace or {})}
                exec(compile(ast.fix_missing_locations(module), notebook_name, "exec"), scope)
                return scope[function_name]
    raise AssertionError(f"{notebook_name}에서 {function_name}을 찾지 못했습니다")


def test_ch11_query_source_matches_ch12_distribution_copy():
    source = [
        json.loads(line)
        for line in (ROOT / "labs/part3/ch11-evaluation/data/evaluation-queries.jsonl")
        .read_text()
        .splitlines()
        if line
    ]
    distributed = json.loads((CH12 / "data/advanced-queries.json").read_text())
    assert source == distributed
    assert {row["split"] for row in source} == {"dev", "test"}
    assert sum(row["split"] == "dev" for row in source) == 15
    assert sum(row["split"] == "test" for row in source) == 15


def test_document_and_chunk_identifiers_preserve_source_position():
    data = json.loads((CH12 / "data/advanced-documents.json").read_text())
    parent_ids = {row["doc_id"] for row in data["parents"]}
    query_ids = {
        doc_id
        for row in json.loads((CH12 / "data/advanced-queries.json").read_text())
        for doc_id in row["gold_doc_ids"]
    }
    assert query_ids <= parent_ids
    for chunk in data["chunks"]:
        match = re.fullmatch(r"(.+)-P(\d{2})-C(\d{2})", chunk["chunk_id"])
        assert match
        assert match.group(1) == chunk["parent_id"]
        assert int(match.group(2)) == chunk["page"]
        assert chunk["parent_id"] in parent_ids


def test_continuity_logs_keep_query_level_evidence_and_scope():
    rows = [
        json.loads(line)
        for line in (CH12 / "runs/advanced-continuity-experiment-log.jsonl")
        .read_text()
        .splitlines()
        if line
    ]
    assert len(rows) == 36
    assert all(row["split"] == "dev" and row["query_count"] == 15 for row in rows)
    assert all(len(row["results"]) == 15 and row["slices"] for row in rows)
    assert all(row["source_chapter"] == "ch12" and row["query_source_chapter"] == "ch11" for row in rows)
    assert all(row["settings"]["candidate_unit"] == "chunk" for row in rows)
    assert all(row["metrics_policy"] == "chunk-candidate-unique-parent-macro-v1" for row in rows)
    assert all(row["comparison_policy"] == "compare-only-pairs-that-differ-by-one-setting" for row in rows)
    assert all(
        result["returned_count"] == len(result["top_results"])
        and all({"doc_id", "page", "chunk_id", "rank"} <= item.keys() for item in result["top_results"])
        for row in rows
        for result in row["results"]
    )
    assert all(row["corpus_fingerprint"] and row["query_fingerprint"] for row in rows)

    test = json.loads((CH12 / "runs/advanced-continuity-test-result.json").read_text())
    assert test["split"] == "test" and test["query_count"] == 15
    assert test["comparison_policy"] == "selected-on-dev-then-evaluate-test-once"
    assert len(test["results"]) == 15 and test["run_date"]

    smoke = json.loads((CH12 / "runs/advanced-continuity-integrated-result.json").read_text())
    assert smoke["run_type"] == "generation_smoke_test"
    assert smoke["split"] == "dev"
    assert smoke["retrieval_metrics"] is None
    assert smoke["generation_evaluation"]["status"] == "not_evaluated"
    assert all(item["chunk_id"].startswith(f"{item['doc_id']}-P{item['page']:02d}-") for item in smoke["retrieved"])

    session_dir = CH12 / "runs/continuity" / rows[0]["run_id"].removeprefix("advanced-continuity-").rsplit("-dev-", 1)[0]
    assert (session_dir / "advanced-continuity-experiment-log.jsonl").read_text() == (CH12 / "runs/advanced-continuity-experiment-log.jsonl").read_text()
    assert (session_dir / "advanced-continuity-test-result.json").read_text() == (CH12 / "runs/advanced-continuity-test-result.json").read_text()
    assert (session_dir / "advanced-continuity-integrated-result.json").read_text() == (CH12 / "runs/advanced-continuity-integrated-result.json").read_text()


def test_student_metric_functions_handle_multi_gold_duplicates_and_empty_gold():
    mixed = [
        {"qid": "Q-MULTI", "question": "도서관 휴관일", "tier": "basic", "split": "dev",
         "answerable": True, "gold_doc_ids": ["D1", "D2", "D2"]},
        {"qid": "Q-EMPTY", "question": "빈 정답", "tier": "basic", "split": "dev",
         "answerable": True, "gold_doc_ids": []},
        {"qid": "Q-NA", "question": "답변 불가", "tier": "basic", "split": "dev",
         "answerable": False, "gold_doc_ids": ["D3"]},
    ]
    eligible_08 = load_notebook_function("08-후보-수와-리랭커-비교.ipynb", "eligible_items")
    assert [item["qid"] for item in eligible_08(mixed)] == ["Q-MULTI"]

    chunks = [{"parent_id": "D1"}, {"parent_id": "D1"}]
    evaluate = load_notebook_function(
        "08-후보-수와-리랭커-비교.ipynb",
        "evaluate",
        {"chunks": chunks, "dev_queries": eligible_08(mixed), "candidate_sets": {"Q-MULTI": np.array([0, 1])}},
    )
    recall, _ = evaluate({"Q-MULTI": np.array([2.0, 1.0])}, candidate_k=2)
    assert recall == 0.5

    empty_evaluate = load_notebook_function(
        "08-후보-수와-리랭커-비교.ipynb", "evaluate", {"chunks": chunks, "dev_queries": []}
    )
    with pytest.raises(ValueError, match="평가 가능한 개발 문항"):
        empty_evaluate({}, candidate_k=2)

    eligible_12 = load_notebook_function("12-종합-튜닝과-실험-로그.ipynb", "eligible_items")
    assert [item["qid"] for item in eligible_12(mixed)] == ["Q-MULTI"]
    metrics = load_notebook_function("12-종합-튜닝과-실험-로그.ipynb", "metrics")
    recall_5, recall_50, _, _ = metrics(["D1", "D1"], ["D1"], ["D1", "D2", "D2"])
    assert (recall_5, recall_50) == (0.5, 0.5)

    mmr = load_notebook_function("10-MMR-다양성-선택.ipynb", "mmr")
    selected = mmr(np.array([[1.0, 0.0]]), np.array([[1.0, 0.0], [0.9, 0.1], [0.0, 1.0]]), k=3)
    assert len(selected) == len(set(selected)) == 3

    metric_chunks = [
        {"parent_id": "D1", "page": 1, "chunk_id": "D1-P01-C01", "text": "도서관 휴관일"},
        {"parent_id": "D2", "page": 1, "chunk_id": "D2-P01-C01", "text": "좌석 예약"},
    ]
    mmr_12 = load_notebook_function("12-종합-튜닝과-실험-로그.ipynb", "mmr")
    evaluate_config = load_notebook_function(
        "12-종합-튜닝과-실험-로그.ipynb",
        "evaluate_config",
        {"eligible_items": eligible_12, "TfidfVectorizer": TfidfVectorizer,
         "chunks": metric_chunks, "mmr": mmr_12, "metrics": metrics},
    )
    config = {"analyzer": "char", "ngram": (2, 3), "report_k": 2, "lambda": 0.8}
    _, _, results = evaluate_config(config, mixed)
    assert [result["qid"] for result in results] == ["Q-MULTI"]
    with pytest.raises(ValueError, match="평가 가능한 문항"):
        evaluate_config(config, mixed[1:])
